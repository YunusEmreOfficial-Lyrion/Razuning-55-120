quest item_ver begin
	state start begin
	
		when 30300.use begin -- 30300 Bilinmeyen Eski Sandık --
		pc . give_item2 ( "71050" , 50 ) -- 50 adet 71050 ver --
		pc . give_item2 ( "72724" , 1 )
		pc . give_item2 ( "71198" , 1 ) 
		pc . give_item2 ( "72728" , 1 ) 
		pc . give_item2 ( "50053" , 1 ) 
		pc . give_item2 ( "50188" , 1 ) 
		pc . give_item2 ( "40004" , 1 )  
		pc . give_item2 ( "31311" , 1 ) 
		pc . give_item2 ( "31312" , 1 )  
		pc . give_item2 ( "53001" , 1 ) -- Buraya kadar sinif belirlemedigimiz icin tum karakterler bu esyaları alacak. Kendi sunucunuzda vermek istediklerinize gore duzenleyin --
		local sinif = pc . get_job ( ) -- keyfimize gore sinif isimli bir degisken atadik. bu degiskeni joba esitledik. artik sinif degiskeni ile job fonksiyonunu yazmadan islem yapabilecegiz--
		if sinif == 0 then  -- ustte de belirttigimiz gibi suan sinif olarak tanimladik ve kullaniyoruz isteseydik pc get job olarak yazabilirdik. -- 
		pc . give_item2 ( "72701" , 1 )  -- sadece savascilara verilen itemler -- 
		pc . give_item2 ( "12209" , 1 ) 
		pc . give_item2 ( "19" , 1 ) 
		pc . give_item2 ( "11209" , 1 ) 
		pc . give_item2 ( "13009" , 1 ) 
		pc . give_item2 ( "14009" , 1 ) 
		pc . give_item2 ( "15009" , 1 ) 
		pc . give_item2 ( "16009" , 1 ) 
		pc . give_item2 ( "17009" , 1 ) 
		pc . give_gold ( "0" )  -- burada gold vermek isterseniz duzenleyebilirsiniz --
		elseif sinif == 1 then  -- sadece ninjalara verilen itemler --
		pc . give_item2 ( "72701" , 1 ) 
		pc . give_item2 ( "12349" , 1 ) 
		pc . give_item2 ( "1009" , 1 ) 
		pc . give_item2 ( "11409" , 1 ) 
		pc . give_item2 ( "13009" , 1 ) 
		pc . give_item2 ( "14009" , 1 ) 
		pc . give_item2 ( "15009" , 1 ) 
		pc . give_item2 ( "16009" , 1 ) 
		pc . give_item2 ( "17009" , 1 ) 
		pc . give_gold ( "0" ) 
		elseif sinif == 2 then -- sadece suralara verilen itemler --
		pc . give_item2 ( "72701" , 1 ) 
		pc . give_item2 ( "12489" , 1 ) 
		pc . give_item2 ( "19" , 1 ) 
		pc . give_item2 ( "11609" , 1 ) 
		pc . give_item2 ( "13009" , 1 ) 
		pc . give_item2 ( "14009" , 1 ) 
		pc . give_item2 ( "15009" , 1 ) 
		pc . give_item2 ( "16009" , 1 ) 
		pc . give_item2 ( "17009" , 1 ) 
		pc . give_gold ( "0" ) 
		elseif sinif == 3 then -- sadece samanlara verilen itemler --
		pc . give_item2 ( "72701" , 1 ) 
		pc . give_item2 ( "12629" , 1 ) 
		pc . give_item2 ( "7009" , 1 ) 
		pc . give_item2 ( "11809" , 1 ) 
		pc . give_item2 ( "13009" , 1 ) 
		pc . give_item2 ( "14009" , 1 ) 
		pc . give_item2 ( "15009" , 1 ) 
		pc . give_item2 ( "16009" , 1 ) 
		pc . give_item2 ( "17009" , 1 ) 
		pc . give_gold ( "0" ) 
		elseif sinif == 4 then -- sadece lycanlara verilen itemler --
		pc . give_item2 ( "72701" , 1 ) 
		pc . give_item2 ( "21509" , 1 ) 
		pc . give_item2 ( "6009" , 1 ) 
		pc . give_item2 ( "21009" , 1 ) 
		pc . give_item2 ( "13009" , 1 ) 
		pc . give_item2 ( "14009" , 1 ) 
		pc . give_item2 ( "15009" , 1 ) 
		pc . give_item2 ( "16009" , 1 ) 
		pc . give_item2 ( "17009" , 1 ) 
		pc . give_gold ( "0" )  
		end 
		end
		
		when 50188.use begin -- 50188 kullanildiginda olacaklar --
		pc.remove_item("50188",1)
		pc.give_item2("25041",1)
		pc.give_item2("76008",3)
		pc.give_item2("72723",1)
		pc.give_item2("50189",1)
		end
		
		when 50189.use begin -- 50189 kullanildiginda olacaklar --
		pc.remove_item("50189",1)
		pc.give_item2("25041",1)
		pc.give_item2("27989",1)
		pc.give_item2("72727",1)
		pc.give_item2("76023",3)
		pc.give_item2("76024",3)
		pc.give_item2("50190",1)
		end
		
		when 50190.use begin -- 50190 kullanildiginda olacaklar--
		pc.remove_item("50190",1)
		pc.give_item2("76011",1)
		pc.give_item2("70005",1)
		pc.give_item2("76016",5)
		pc.give_item2("50191",1)
		end
		
		when 50191.use begin -- 50191 kullanildiginda olacaklar--
		pc.remove_item("50191",1)
		pc.give_item2("76003",1)
		pc.give_item2("70005",1)
		pc.give_item2("71153",1)
		pc.give_item2("76011",1)
		pc.give_item2("50192",1)
		end
		
		when 50192.use begin -- 50192 kullanildiginda olacaklar --
		pc.remove_item("50192",1)
		pc.give_item2("76003",1)
		pc.give_item2("70005",1)
		pc.give_item2("76019",5)
		pc.give_item2("30180",1)
		pc.give_item2("50193",1)
		end
		
		when 50193.use begin -- 50193 kullanildiginda olacaklar --
		pc.remove_item("50193",1)
		pc.give_item2("70005",1)
		pc.give_item2("76003",1)
		pc.give_item2("76009",3)
		pc.give_item2("50194",1)
		end
		
		when 50194.use begin -- 50194 kullanildiginda olacaklar--
		pc.remove_item("50194",1)
		pc.give_item2("76003",1)
		pc.give_item2("70005",1)
		pc.give_item2("76013",3)
		pc.give_item2("76014",3)
		pc.give_item2("50195",1)

		end
		
		when 50195.use begin -- 50195 kullanildiginda olacaklar --
		pc.remove_item("50195",1)
		pc.give_item2("76003",1)
		pc.give_item2("70005",1)
		pc.give_item2("72728",1)
		pc.give_item2("76020",3)
		pc.give_item2("50196",1)
			
		end
		
		when 50196.use begin -- 50195 kullanildiginda olacaklar --
		pc.remove_item("50196",1)
		pc.give_item2("76002",3)
		pc.give_item2("76010",3)
		pc.give_item2("72724",1)
		pc.give_item2("76015",1)
		
		end
	end
end
		
		