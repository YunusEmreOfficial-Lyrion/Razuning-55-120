--[[
Server Files Author : OGStudio
Skype : admin@mmovakti.com
Website : www.metin2files.com
--]]
quest gelismis_yonetici_sistemi begin
        state start begin
        when letter with pc.is_gm() and pc.get_gm_level() == 5 begin
			send_letter ("*GM: Y�netim Paneli")
			q.set_icon("scroll_open_blue.tga")
        end
        when info or button with pc.is_gm() and pc.get_gm_level() == 5 begin
			uyariO = "Bilgilendirme:"
			uyariOL = "Uyar�:"
			yoneticiIsim = pc.get_name()
			if not pc.get_gm_level() == 5 then
				syschat("Bu sistem sadece oyun y�neticilerine �zeldir.")
				return
			end
			yoneticiSecim = select("Y�netim Paneli","Kapat")
			if yoneticiSecim == 1 then
				say_size(350,300)
				yoneticiPanelIslemler = {
					"Drop De�i�tir",
					"Etkinlik Y�netimi",
					"Grup Arama Y�netimi",
					"E�ya Katlama Y�netimi",
					"Kuyumcu Y�netimi",
					"Zindan Y�netimi",
					"�mparatorluk De�i�tir",
					"Para G�ncelle",
					"Cinsiyet De�i�tir",
					"Oyuncuyu Sustur",
					"Derece De�i�tir",
					"E�ya G�nder",
					"Stat� S�f�rla",
					"Harita Bilgileri",
					"Flag Bilgileri",
					"Captcha Test"
				}
				yoneticiPanelIslemlerSay = tonumber(table.getn(yoneticiPanelIslemler))
				yoneticiPanelIslemler[yoneticiPanelIslemlerSay + 1] = "Kapat"
				yoneticiPanelSecim = select_table(yoneticiPanelIslemler)
				if yoneticiPanelSecim == 1 then
					say_size(350,400)
					say_title(uyariO)
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("")
					say_reward("Droplar� hangi oranda a�mak istiyorsun? ")
					
					local drop_sec = select ("250 Drop A� ", "300 Drop A� ", "500 Drop A� ", "750 Drop A� ", "1000 Drop A� ", "Kendin Belirle ", "Drop Kapat ","Vazge� ")
					if (drop_sec == 1) then
						say("Droplar� 250 olarak a�mak istiyor musun? ")
						local islem = select ("Evet ","Hay�r ")
						if (islem == 1) then
							say("Droplar Ba�ar�yla a��ld�. (250)")
							command("priv_empire 0 1:shop 250 99999")
							command("priv_empire 0 2:shop 250 99999")
							command("priv_empire 0 3:gold 250 99999")
							command("priv_empire 0 4:exp 250 99999")
							game.set_event_flag("yang_drop_oran",50)
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (drop_sec == 2) then
						say("Droplar� 300 olarak a�mak istiyor musun? ")
						local islem = select ("Evet ","Hay�r ")
						if (islem == 1) then
							say("Droplar Ba�ar�yla a��ld�. (300)")
							command("priv_empire 0 1:shop 300 99999")
							command("priv_empire 0 2:shop 300 99999")
							command("priv_empire 0 3:gold 300 99999")
							command("priv_empire 0 4:exp 300 99999")
							game.set_event_flag("yang_drop_oran",100)
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (drop_sec == 3) then
						say("Droplar� 500 olarak a�mak istiyor musun? ")
						local islem = select ("Evet ","Hay�r ")
						if (islem == 1) then
							say("Droplar Ba�ar�yla a��ld�. (500)")
							command("priv_empire 0 1:shop 500 99999")
							command("priv_empire 0 2:shop 500 99999")
							command("priv_empire 0 3:gold 500 99999")
							command("priv_empire 0 4:exp 500 99999")
							game.set_event_flag("yang_drop_oran",200)
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (drop_sec == 4) then
						say("Droplar� 750 olarak a�mak istiyor musun? ")
						local islem = select ("Evet ","Hay�r ")
						if (islem == 1) then
							say("Droplar Ba�ar�yla a��ld�. (750)")
							command("priv_empire 0 1:shop 750 99999")
							command("priv_empire 0 2:shop 750 99999")
							command("priv_empire 0 3:gold 750 99999")
							command("priv_empire 0 4:exp 750 99999")
							game.set_event_flag("yang_drop_oran",300)
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (drop_sec == 5) then
						say("Droplar� 1000 olarak a�mak istiyor musun? ")
						local islem = select ("Evet ","Hay�r ")
						if (islem == 1) then
							say("Droplar Ba�ar�yla a��ld�. (1000)")
							command("priv_empire 0 1:shop 1000 99999")
							command("priv_empire 0 2:shop 1000 99999")
							command("priv_empire 0 3:gold 1000 99999")
							command("priv_empire 0 4:exp 1000 99999")
							game.set_event_flag("yang_drop_oran",400)
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (drop_sec == 6) then
						say("Droplar� a�mak istiyor musun? ")
						local islem = select ("Yang ","Exp ", "E�ya ", "Kapat ")
						if (islem == 1) then
							say("Yang Deger Giriniz:")
							local degeroguz = input()
							game.set_event_flag("yang_drop_oran",degeroguz)
							command("priv_empire 0 3:gold "..degeroguz.." 99999")
							notice_all("Yang Droplar� %"..degeroguz.." De�erinde A��lm��t�r.")
						elseif (islem == 2) then
							say("Exp Deger Giriniz:")
							local degeroguz = input()
							command("priv_empire 0 4:exp "..degeroguz.." 99999")
							notice_all("Exp Droplar� %"..degeroguz.." De�erinde A��lm��t�r.")
						elseif (islem == 3) then
							say("E�ya Deger Giriniz:")
							local degeroguz = input()
							command("priv_empire 0 1:shop "..degeroguz.." 99999")
							command("priv_empire 0 2:shop "..degeroguz.." 99999")
							notice_all("E�ya Droplar� %"..degeroguz.." De�erinde A��lm��t�r.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (drop_sec == 7) then
						say("Droplar� kapatmak istiyor musun? ")
						local islem = select ("Evet ","Hay�r ")
						if (islem == 1) then
							say("Droplar Ba�ar�yla kapat�ld�. (0)")
							command("priv_empire 0 1:shop 0 1")
							command("priv_empire 0 2:shop 0 1")
							command("priv_empire 0 3:gold 0 1")
							command("priv_empire 0 4:exp 0 1")
							game.set_event_flag("yang_drop_oran",1)
						end
						send_letter ("GM: Y�netim Paneli")
					end
					
				elseif yoneticiPanelSecim == 2 then
					say_size(350,400)
					say_title(uyariO)
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("")
					say_reward("Hangi etkinli�i y�netmek istiyorsunuz? ")
					
					local etkinlik_sec = select ("Aktif Etkinlikler ", "Otomatik Etkinlikler ", "Binek Par�omeni ", "Sevgililer G�n� ", "Bulmaca Kutusu ", "Oyma Ta� ", "Futbol Topu ", "Okey Kart� ", "Ay����� ", "Alt�gen ", "Kelime ", "Derece Puan� ", "D�nya Kupas� ", "Olimpiyat ", "Cad�lar Bayram� ", "Evcil Hayvan ", "Y�lba�� ", "Ramazan Simiti ", "D�nya Kitap G�n� ", "Y�ld�n�m� Paras� ", "Baashido Avc�lar� ", "S�per Metin ", "Bal�k Yapboz ", "Metin Katlama ", "Soru Cevap ", "Evrim Puani ", "Y�kseltme ", "Yaz ", "Ronark ", "Paskalya ", "Oyuncu G�n� ", "Sans Kutusu ", "Simya Takas", "Trivia", "Yutnori", "Kral� Yakala", "Patron Avc�lar� ","Vazge� ")
					if (etkinlik_sec == 1) then
						say_size(350,350)
						local event_name = gelismis_yonetici_sistemi.EventListesi(0)
						local event_flag = gelismis_yonetici_sistemi.EventListesi(1)
						local event_name_list = {}
						local event_flag_list = {}
						say_title("Etkinlik Y�netimi -> Aktif Etkinlikler: ")
						for i=1, table.getn(event_flag) do
							if event_flag[i] == "auto_event_source" then
								break
							end
							if game.get_event_flag(event_flag[i]) == 1 then
								table.insert(event_name_list, event_name[i])
								table.insert(event_flag_list, event_flag[i])
							end
						end
						if table.getn(event_name_list) == 0 then
							say_reward("Aktif etkinlik bulunmuyor.")
							return
						end
						say_reward("Bitirmek istedi�in etkinli�i se�.")
						table.insert(event_name_list, "�ptal")
						local list = select_table(event_name_list)
						if list == table.getn(event_name_list)then return end
						say_yellow(event_name_list[list].." kapat�yorsun.")
						say_reward("Devam etmek istedi�ine eminmisin? ")
						local confirm = select("Evet ", "Hay�r ")
						if confirm == 2 then return end
						gelismis_yonetici_sistemi.EventYonetim(0, event_name_list[list], event_flag_list[list])
					elseif (etkinlik_sec == 2) then
						say("Otomatik etkinlikler i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							setskin(1)
							say_size(350,350)
							game.set_event_flag("auto_event_source",1)
							syschat_acik_mavi_system("Otomatik Etkinlikler aktifle�tirilmi�tir!")
							cmdchat("EventListesiAc")
						else
							game.set_event_flag("auto_event_source",0)
							syschat_acik_mavi_system("Otomatik Etkinlikler devred��� b�rak�ld�!")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 3) then
						say("Binek par�omeni etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_mount_drop",1)
							notice_all("<Etkinlik> Binek Par�omeni Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_mount_drop",0)
							notice_all("<Etkinlik> Binek Par�omeni Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 4) then
						say("Sevgililer g�n� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_valentine_drop",1)
							notice_all("<Etkinlik> Amor'un Sand��� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_valentine_drop",0)
							notice_all("<Etkinlik> Amor'un Sand��� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 5) then
						say("Bulmaca Kutusu etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_kids_drop",1)
							notice_all("<Etkinlik> Bulmaca Kutusu Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_kids_drop",0)
							notice_all("<Etkinlik> Bulmaca Kutusu Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 6) then
						say("Oyma Ta� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_carving_stone_drop",1)
							notice_all("<Etkinlik> Oyma Ta� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_carving_stone_drop",0)
							notice_all("<Etkinlik> Oyma Ta� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 7) then
						say("Futbol Topu etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_football_drop",1)
							notice_all("<Etkinlik> Futbol Topu Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_football_drop",0)
							notice_all("<Etkinlik> Futbol Topu Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 8) then
						say("Okey Kart etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("cards_event",1)
							notice_all("<Etkinlik> Okey Kart Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("cards_event",0)
							notice_all("<Etkinlik> Okey Kart Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 9) then
						say("Ay����� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_moon_drop",1)
							notice_all("<Etkinlik> Ay����� Define Sand��� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_moon_drop",0)
							notice_all("<Etkinlik> Ay����� Define Sand��� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 10) then
						say("Alt�gen etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_hexagon_drop",1)
							notice_all("<Etkinlik> Alt�gen Hediye Paketi Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_hexagon_drop",0)
							notice_all("<Etkinlik> Alt�gen Hediye Paketi Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 11) then
						say("Kelime etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("word_event_drop",1)
							notice_all("<Etkinlik> Kelime Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("word_event_drop",0)
							notice_all("<Etkinlik> Kelime Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 12) then
						say("Derece Puan� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("alignment_event",1)
							notice_all("<Etkinlik> Derece Puan� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("alignment_event",0)
							notice_all("<Etkinlik> Derece Puan� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 13) then
						say("D�nya Kupas� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("dunyakupasi_event",1)
							notice_all("<Etkinlik> D�nya Kupas� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("dunyakupasi_event",0)
							notice_all("<Etkinlik> D�nya Kupas� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 14) then
						say("Olimpiyat etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_olympic_drop",1)
							notice_all("<Etkinlik> Olimpiyat Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_olympic_drop",0)
							notice_all("<Etkinlik> Olimpiyat Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 15) then
						say("Cad�lar Bayram� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_halloween_drop",1)
							notice_all("<Etkinlik> Cad�lar Bayram� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_halloween_drop",0)
							notice_all("<Etkinlik> Cad�lar Bayram� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 16) then
						say("Evcil Hayvan etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_pet_drop",1)
							notice_all("<Etkinlik> Evcil Hayvan Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_pet_drop",0)
							notice_all("<Etkinlik> Evcil Hayvan Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 17) then
						say("Y�lba�� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_xmas_drop",1)
							notice_all("<Etkinlik> Y�lba�� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_xmas_drop",0)
							notice_all("<Etkinlik> Y�lba�� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 18) then
						say("Ramazan Simiti etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_ramadan_drop",1)
							notice_all("<Etkinlik> Ramazan Simiti Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_ramadan_drop",0)
							notice_all("<Etkinlik> Ramazan Simiti Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 19) then
						say("D�nya Kitap G�n� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("worldbookday",1)
							notice_all("<Etkinlik> D�nya Kitap G�n� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("worldbookday",0)
							notice_all("<Etkinlik> D�nya Kitap G�n� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 20) then
						say("Y�ld�n�m� Paras� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2017_year_round_event",1)
							notice_all("<Etkinlik> Y�ld�n�m� Paras� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2017_year_round_event",0)
							notice_all("<Etkinlik> Y�ld�n�m� Paras� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 21) then
						say("Baashido Avc�lar� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2018_boss_hunters_event",1)
							game.set_event_flag("easter_drop",1)
							notice_all("<Etkinlik> Baashido Avc�lar� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2018_boss_hunters_event",0)
							game.set_event_flag("easter_drop",0)
							notice_all("<Etkinlik> Baashido Avc�lar� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 22) then
						say("S�per Metin etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("super_metin_event",1)
							notice_all("<Etkinlik> S�per Metin Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("super_metin_event",0)
							notice_all("<Etkinlik> S�per Metin Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					elseif (etkinlik_sec == 23) then
						say("Bal�k Yapboz etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("2018_fish_event",1)
							notice_all("<Etkinlik> Bal�k Yapboz Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("2018_fish_event",0)
							notice_all("<Etkinlik> Bal�k Yapboz Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 24) then
						say("Metin Katlama etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("scp_metinkatla",1)
							notice_all("<Etkinlik> Metin Katlama Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("scp_metinkatla",0)
							notice_all("<Etkinlik> Metin Katlama Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 25) then
						say("Soru etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							say("Soru Etkinli�i Oran� Giriniz:")
							local degeroguz = input()
							game.set_event_flag("scp_soru_event",degeroguz)
							notice_all("<Etkinlik> Soru Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("scp_soru_event",0)
							notice_all("<Etkinlik> Soru Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 26) then
						say("Evrim Puani etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("rarity_event",1)
							notice_all("<Etkinlik> Evrim Puani Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("rarity_event",0)
							notice_all("<Etkinlik> Evrim Puani Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 27) then
						say("Y�kseltme etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("yukseltme_event",1)
							notice_all("<Etkinlik> Y�kseltme Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("yukseltme_event",0)
							notice_all("<Etkinlik> Y�kseltme Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 28) then
						say("Yaz etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("scp_yaz_etk",1)
							notice_all("<Etkinlik> Yaz Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("scp_yaz_etk",0)
							notice_all("<Etkinlik> Yaz Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 29) then
						say("Ronark etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("blood_dungeon_login",1)
							notice_all("<Etkinlik> Ronark Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("blood_dungeon_login",0)
							notice_all("<Etkinlik> Ronark Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 30) then
						say("Paskalya etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("paskalya",1)
							notice_all("<Etkinlik> Paskalya Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("paskalya",0)
							notice_all("<Etkinlik> Paskalya Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 31) then
						say("Oyuncu G�n� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("oyuncu_gunu",1)
							notice_all("<Etkinlik> Oyuncu G�n� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("oyuncu_gunu",0)
							notice_all("<Etkinlik> Oyuncu G�n� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 32) then
						say("Sans Kutusu etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("sans_kutusu",1)
							notice_all("<Etkinlik> �ans Kutusu Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("sans_kutusu",0)
							notice_all("<Etkinlik> �ans Kutusu Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 33) then
						say("Simya Takas etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("simyatakas",1)
							notice_all("<Etkinlik> Simya Takas Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("simyatakas",0)
							notice_all("<Etkinlik> Simya Takas Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 34) then
						say("Trivia etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("trivia",1)
							notice_all("<Etkinlik> Trivia Etkinli�i Ba�lad�!")
							local s = number(1, 4)
							if s == 1 then
								game.set_event_flag("trivia_random", 0)
								notice_all ("Metin2 hangi sene kurulmu�tur?")
							end
							if s == 2 then
								game.set_event_flag("trivia_random", 1)
								notice_all ("Metin2 ka� dilde hizmet vermektedir?")
							end
							if s == 3 then
								game.set_event_flag("trivia_random", 2)
								notice_all ("Metin2 oyununda ka� karakter bulunur?")
							end
							if s == 4 then
								game.set_event_flag("trivia_random", 3)
								notice_all ("Metin2 oyununda ka� krall�k vard�r?")
							end
						else
							game.set_event_flag("trivia",0)
							notice_all("<Etkinlik> Trivia Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 35) then
						say("Yutnori etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("enable_yutnori",1)
							notice_all("<Etkinlik> Yutnori Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("enable_yutnori",0)
							notice_all("<Etkinlik> Yutnori Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 37) then
						say("Kral� Yakala etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("enable_catch_king_event",1)
							notice_all("<Etkinlik> Kral� Yakala Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("enable_catch_king_event",0)
							notice_all("<Etkinlik> Kral� Yakala Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
					elseif (etkinlik_sec == 38) then
						say("Patron Avc�lar� etkinli�i i�in se�iminizi yap�n�z ")
						local islem = select ("Ba�lat ","Durdur ")
						if (islem == 1) then
							game.set_event_flag("enable_attendance_event",1)
							game.set_event_flag("easter_drop",1)
							notice_all("<Etkinlik> Patron Avc�lar� Etkinli�i Ba�lad�!")
							notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
						else
							game.set_event_flag("enable_attendance_event",0)
							game.set_event_flag("easter_drop",0)
							notice_all("<Etkinlik> Patron Avc�lar� Etkinli�i Sona Erdi!")
							notice_all("Y�netim ekibi iyi oyunlar diler.")
						end
						send_letter ("GM: Y�netim Paneli")
					end
				elseif yoneticiPanelSecim == 3 then
					say_title(uyariO)
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("")
					local secenekler = select(gameforge.group_search._050_say,gameforge.group_search._060_say,gameforge.group_search._061_say,gameforge.group_search._070_say)
					if secenekler == 4 then return
					else if secenekler == 3 then
						local durum2 = game.get_event_flag("group_notice")
							if durum2 == 0 then
								say(gameforge.group_search._092_say)
								say("")
								local ac = select(locale.yes,locale.no)
								if ac == 1 then
									chat(gameforge.group_search._096_say)
									game.set_event_flag("group_notice",1)
								end
							else
								say(gameforge.group_search._093_say)
								say("")
								local ac2 = select(locale.yes,locale.no)
								if ac2 == 1 then
									chat(gameforge.group_search._097_say)
									game.set_event_flag("group_notice",0)
								end
							end
					else if secenekler == 2 then
						local durum = game.get_event_flag("group_match_giris")
						if durum == 0 then
							say(gameforge.group_search._080_say)
							say("")
							local ac = select(locale.yes,locale.no)
							if ac == 1 then
								chat(gameforge.group_search._094_say)
								game.set_event_flag("group_match_giris",1)
							end
						else
							say(gameforge.group_search._090_say)
							say("")
							local ac2 = select(locale.yes,locale.no)
							if ac2 == 1 then
								chat(gameforge.group_search._095_say)
								game.set_event_flag("group_match_giris",0)
							end
						end
					else if secenekler == 1 then
						local secenekler2 = select(group_match.dungeon_name(0),group_match.dungeon_name(1),group_match.dungeon_name(2),group_match.dungeon_name(3),group_match.dungeon_name(4),group_match.dungeon_name(5),gameforge.group_search._070_say)
						if secenekler2 == 7 then
							return
						else if secenekler2 == 3 or secenekler2 == 5 then
							say(string.format(gameforge.group_search._010_say, group_match.giris_levelleri(secenekler2 - 1)))
							if group_match.is_new_need_items() == 1 then
								say(string.format(gameforge.group_search._020_say,group_match.ayarlar_itemler_count(secenekler2 - 1), item_name(group_match.ayarlar_itemler(secenekler2 - 1))))
							end
							say(string.format(gameforge.group_search._030_say, group_match.ayarlar_giris(secenekler2 - 1)))
							say(string.format(gameforge.group_search._035_say, group_match.ayarlar_kayitlar(secenekler2 - 1)))
						else if secenekler2 == 1 then 
							say(string.format(gameforge.group_search._010_say, group_match.giris_levelleri(secenekler2 - 1)))
							say(string.format(gameforge.group_search._020_say, group_match.ayarlar_itemler_count(secenekler2 - 1), item_name(group_match.ayarlar_itemler(secenekler2 - 1))))
							say(string.format(gameforge.group_search._040_say, group_match.ayarlar_itemler_count(6), item_name(group_match.ayarlar_itemler(6))))
							say(string.format(gameforge.group_search._030_say, group_match.ayarlar_giris(secenekler2 - 1)))
							say(string.format(gameforge.group_search._035_say, group_match.ayarlar_kayitlar(secenekler2 - 1)))
						else
							say(string.format(gameforge.group_search._010_say, group_match.giris_levelleri(secenekler2 - 1)))
							say(string.format(gameforge.group_search._020_say, group_match.ayarlar_itemler_count(secenekler2 - 1), item_name(group_match.ayarlar_itemler(secenekler2 - 1))))
							say(string.format(gameforge.group_search._030_say, group_match.ayarlar_giris(secenekler2 - 1)))
							say(string.format(gameforge.group_search._035_say, group_match.ayarlar_kayitlar(secenekler2 - 1)))
						end
				end end end end end end
				elseif yoneticiPanelSecim == 4 then
					setskin(1)
					say_title(uyariO)
					say_orange("E�ya Katlama Y�netimi")
					say("Merhabalar "..pc.name)
					say("")
					say_reward("Aktif ayarlar:")
					say_reward("Ayarlar her reload q �ekildiginde sifirlan�r!")
					say("")
					say("Evet Durumu: "..gelismis_yonetici_sistemi.isOpen())
					say("Event �tem �smi: "..item_name(scpEventOptions["itemVnum"]))
					say("Event Drop Oran�: "..scpEventOptions["dropPer"].."%")
					say("Max Level Fark�: "..scpEventOptions["maxLevel"])
					say("")
					say_reward(" ��lemlere devam etmek istiyor musunuz?")
					if select("Evet", "Hay�r") == 2 then return end
					local main = select("Evet Durumu De�i�tir", "Event �tem Kodu De�i�tir", "Event Drop Oran� De�i�tir", "Max Level Fark� De�i�tir", "Iptal")
					if main == 1 then
						if scpEventOptions["isOpen"] == 0 then
							if not gelismis_yonetici_sistemi.canOpenAble() then syschat("GM:: Ge�ersiz de�er alg�land�!") return end
							scpEventOptions["isOpen"] = 1
							syschat("GM:: Event a��ld�.")
							notice_all("<Drop A��l�� Duyurusu> Drop Nesnesi: "..item_name(scpEventOptions["itemVnum"]).." || Drop Oran�: "..scpEventOptions["dropPer"].."% || Max. Level Limiti: "..scpEventOptions["maxLevel"])
						else
							scpEventOptions["isOpen"] = 0
							syschat("GM:: Event kapat�ld�.")
							notice_all("<Drop Duyurusu> Drop eventi kapat�ld�.")
						end
					elseif main == 2 then
						say("Yeni item kodunu giriniz:")
						local vnum = tonumber(input()) or 0
						if vnum < 2 then syschat("GM:: Ge�ersiz giri�!") return end
						local name = item_name(vnum)
						if name == "" then syschat("GM:: Ge�ersiz giri�!") return end
						scpEventOptions["itemVnum"] = vnum
						syschat("GM:: Yeni drop item ismi: "..item_name(vnum))
						if scpEventOptions["isOpen"]==0 then return end
						notice_all("<Drop G�ncelleme Duyurusu> Drop Nesnesi: "..item_name(vnum).." || Drop Oran�: "..scpEventOptions["dropPer"].."% || Max. Level Limiti: "..scpEventOptions["maxLevel"])
					elseif main == 3 then
						say("Yeni item drop oran�n� giriniz:")
						say_reward("1 ile 100 aras�nda giriniz.")
						local drop = tonumber(input()) or 0
						if drop < 1 then syschat("GM:: Ge�ersiz giri�!") return end
						scpEventOptions["dropPer"] = drop
						syschat("GM:: Yeni drop oran�: "..drop.."%")
						if scpEventOptions["isOpen"]==0 then return end
						notice_all("<Drop G�ncelleme Duyurusu> Drop Nesnesi: "..item_name(scpEventOptions["itemVnum"]).." || Drop Oran�: "..drop.."% || Max. Level Limiti: "..scpEventOptions["maxLevel"])
					elseif main == 4 then
						say("Yeni max. level limitini giriniz:")
						local level = tonumber(input()) or 0
						if level < 0 then syschat("GM:: Ge�ersiz giri�!") return end
						scpEventOptions["maxLevel"] = level
						syschat("GM:: Yeni max. level limiti: "..level)
						if scpEventOptions["isOpen"]==0 then return end
						notice_all("<Drop G�ncelleme Duyurusu> Drop Nesnesi: "..item_name(scpEventOptions["itemVnum"]).." || Drop Oran�: "..scpEventOptions["dropPer"].."% || Max. Level Limiti: "..level)
					end
					send_letter ("GM: Y�netim Paneli")
				elseif yoneticiPanelSecim == 5 then
					say_title(uyariO)
					say_orange("Kuyumcu Y�netimi")
					say("")
					local m_s = select("Sistemi A�/Kapat", "De�erleri De�i�tir", "Pencereyi Kapat")
					if m_s == 1 then
						if game.get_event_flag("scp_altin")==0 then
							game.set_event_flag("scp_altin", 1)
						else
							game.set_event_flag("scp_altin", 0)
						end
					elseif m_s == 2 then
						local sec_tb={"Gram Alt�n"," �eyrek Alt�n"," Yar�m Alt�n"," Tam Alt�n", "Pencereyi Kapat"}
						local my_t = select_table(sec_tb)
						if my_t==table.getn(sec_tb) then return end
						say(sec_tb[my_t])
						say("Olmas�n� istedi�iniz de�eri M cinsinden giriniz.")
						local my_d = tonumber(input())
						if my_d == 0 or my_d == nil then return end
						gelismis_yonetici_sistemi.set_cost(my_t, my_d)
					end
					send_letter ("GM: Y�netim Paneli")
				elseif yoneticiPanelSecim == 6 then
					say_size(350,400)
					say_title(uyariO)
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("")
					say_reward("Hangi zindan� y�netmek istiyorsunuz? ")
					
					local zindan_sec = select ("T�m Zindanlar ", "�eytan Kulesi ", "Mavi Ejderha ", "Ye�il Ejderha ", "Razad�r ", "Nemere ", "Ork Zindan� ", "Katakomb ", "Jotun ", "Ol� Zorba ", "Kaptan Korsan ", "Wju Mantar ", "Barones ", "K�rm�z� Ejderha ","Vazge� ")
					if (zindan_sec == 1) then
						send_letter ("GM: Y�netim Paneli")
						setskin(1)
						say_size(350,350)
						say_title(uyariO)
						say("T�m Zindanlar�n Y�netimi")
						local ms = select("Zindan Giri�lerini A� ","Zindan Giri�lerini Kapat","(Pencereyi Kapat)")
						if ms == 1 then
							setskin(0)
							game.set_event_flag("zindan_kapat", 0)
							game.set_event_flag("scp_barones_sys", 2)
							game.set_event_flag("scp_blued_sys", 2)
							game.set_event_flag("scp_deadbully_sys", 2)
							game.set_event_flag("scp_kule_sys", 2)
							game.set_event_flag("scp_esrar_sys", 2)
							game.set_event_flag("scp_flamed_sys", 2)
							game.set_event_flag("scp_greendrg_sys", 2)
							game.set_event_flag("scp_gizem_sys", 2)
							game.set_event_flag("scp_green_drg_sys", 2)
							game.set_event_flag("scp_kaptan_sys", 2)
							game.set_event_flag("scp_mantar_sys", 2)
							game.set_event_flag("scp_ork_sys", 2)
							game.set_event_flag("scp_red_drg_sys", 2)
							game.set_event_flag("scp_snowd_sys", 2)
							
							game.set_event_flag("blued_max", 500)
							game.set_event_flag("deviltower_max", 500)
							game.set_event_flag("esrar_max", 500)
							game.set_event_flag("gizem_max", 500)
							game.set_event_flag("greend_max", 500)
							syschat_acik_mavi("Zindan giri�leri aktif edilmi�tir.")
						elseif ms == 2 then
							game.set_event_flag("zindan_kapat", 1)
							game.set_event_flag("scp_barones_sys", 0)
							game.set_event_flag("scp_blued_sys", 0)
							game.set_event_flag("scp_deadbully_sys", 0)
							game.set_event_flag("scp_kule_sys", 0)
							game.set_event_flag("scp_esrar_sys", 0)
							game.set_event_flag("scp_flamed_sys", 0)
							game.set_event_flag("scp_greendrg_sys", 0)
							game.set_event_flag("scp_gizem_sys", 0)
							game.set_event_flag("scp_green_drg_sys", 0)
							game.set_event_flag("scp_kaptan_sys", 0)
							game.set_event_flag("scp_mantar_sys", 0)
							game.set_event_flag("scp_ork_sys", 0)
							game.set_event_flag("scp_red_drg_sys", 0)
							game.set_event_flag("scp_snowd_sys", 0)
							syschat_acik_mavi("Zindan giri�leri kapat�lm��t�r.")
						end
					elseif (zindan_sec == 2) then
						send_letter ("GM: Y�netim Paneli")
						setskin(1)
						say_size(350,350)
						say_title(uyariO)
						say("�eytan Kulesi Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_kule_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==65 then
								setskin(0)
								syschat("-------------------------GM: Kule Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 660000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM: Kule Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in kule �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("deviltower_max", tot)
							end
						end
					elseif (zindan_sec == 3) then
						say_title(uyariO)
						setskin(1)
						say("Mavi Ejderha Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_blued_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==73 then
								setskin(0)
								syschat("-------------------------GM: Mavi Ejderha Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 2070000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  Mavi Ejderha Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in Sura Ruhu �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("blued_max", tot)
							end
						end
					elseif (zindan_sec == 4) then
						say_title(uyariO)
						setskin(1)
						say("Yesil Ejderha Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_greendrg_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==358 then
								setskin(0)
								syschat("-------------------------GM: Yesil Ejderha Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 3680000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  Yesil Ejderha Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in Yesil Ejderha Bek�isi �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("greend_max", tot)
							end
						end
					elseif (zindan_sec == 5) then
						say_title(uyariO)
						setskin(1)
						say("Razador Zindan Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_flamed_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==62 then
								setskin(0)
								syschat("-------------------------GM: Razador Zindan Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 3510000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  Razador Zindan Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in Razador Zindan Bek�isi �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("flamed_max", tot)
							end
						end
					elseif (zindan_sec == 6) then
						say_title(uyariO)
						setskin(1)
						say("Nemere Zindan Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_snowd_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==61 then
								setskin(0)
								syschat("-------------------------GM: Nemere Zindan Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 3520000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  Nemere Zindan Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in Nemere Zindan Bek�isi �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("snowd_max", tot)
							end
						end
					elseif (zindan_sec == 7) then
						say_title(uyariO)
						setskin(1)
						say("Ork Zindan Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_ork_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==70 then
								setskin(0)
								syschat("-------------------------GM: Ork Zindan Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 3640000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  Ork Zindan Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in Ork Zindan Bek�isi �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("orcmaze_max", tot)
							end
						end
					elseif (zindan_sec == 8) then
						say_title(uyariO)
						setskin(1)
						say("Katakomb Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_catacomb_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==65 then
								setskin(0)
								syschat("-------------------------GM: Katakomb Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 2160000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  Katakomb Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in Katakomb Bek�isi �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("catacomb_max", tot)
							end
						end
					elseif (zindan_sec == 9) then
						say_title(uyariO)
						setskin(1)
						say("Jotun Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_jotun_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==353 then
								setskin(0)
								syschat("-------------------------GM: Jotun Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 3530000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  Jotun Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in Jotun Bek�isi �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("jotun_max", tot)
							end
						end
					elseif (zindan_sec == 10) then
						say_title(uyariO)
						setskin(1)
						say("�l� Zorba Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_deadbully_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==502 then
								setskin(0)
								syschat("-------------------------GM: �l� Zorba Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 2090000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  �l� Zorba Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in �l� Zorba Bek�isi �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("deadbully_max", tot)
							end
						end
					elseif (zindan_sec == 11) then
						say_title(uyariO)
						setskin(1)
						say("Kaptan Korsan Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_kaptan_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==502 then
								setskin(0)
								syschat("-------------------------GM: Kaptan Korsan Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 2100000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  Kaptan Korsan Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in Kaptan Korsan Bek�isi �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("kaptan_max", tot)
							end
						end
					elseif (zindan_sec == 12) then
						say_title(uyariO)
						setskin(1)
						say("Mantar Tap�na�� Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_mantar_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==68 then
								setskin(0)
								syschat("-------------------------GM: Mantar Tap�na�� Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 3660000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  Mantar Tap�na�� Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in Mantar Tap�na�� Bek�isi �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("mantar_max", tot)
							end
						end
					elseif (zindan_sec == 13) then
						say_title(uyariO)
						setskin(1)
						say("Barones Tap�na�� Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_barones_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==359 then
								setskin(0)
								syschat("-------------------------GM: Barones Tap�na�� Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 3620000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  Barones Tap�na�� Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in Barones Tap�na�� Bek�isi �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("barones_max", tot)
							end
						end
					elseif (zindan_sec == 14) then
						say_title(uyariO)
						setskin(1)
						say("K�rm�z� Ejderha Tap�na�� Harita Y�netimi")
						local ms = select("Sistem Durumunu Degistir","T�m Odalarin Bilgilerini Al","Max. Oda Sayisini Belirle","(Pencereyi Kapat)")
						if ms == 1 then
							local dus = select("Sistemi Kapat","Sadece Oda Kurmayi Kapat","Sistemi A� ","(Pencereyi Kapat)")
							setskin(0)
							game.set_event_flag("scp_red_drg_sys", dus-1)
						elseif ms == 2 then
							if pc.get_map_index()==358 then
								setskin(0)
								syschat("-------------------------GM: K�rm�z� Ejderha Tap�na�� Taramasi Basladi----------------------------")
								for i=0, 999 do
									local ind = 3650000+i
									if d.find(ind) then
										syschat("<< Oda No: "..i.." || Level: "..d.getf_from_map_index("level", ind).." || Sifre:"..d.getf_from_map_index("sifre", ind).." || Dk �nce Basladi: "..math.ceil((get_global_time()-d.getf_from_map_index("lgt", ind))/60).." >>")
									end
								end
								syschat("-------------------------GM:  K�rm�z� Ejderha Tap�na�� Taramasi Bitti-------------------------------")
							else
								syschat_acik_mavi("Bilgileri g�rebilmek i�in K�rm�z� Ejderha Tap�na�� Bek�isi �n�nde olmal�s�n!")
							end
						elseif ms == 3 then
							local tot = tonumber(input()) or 0
							if tot > 0 then
								game.set_event_flag("red_drg_max", tot)
							end
						end
					elseif (zindan_sec == 15) then
						return
					end
				elseif yoneticiPanelSecim == 7 then
					say_title(uyariO)
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("Buradan oyuncunun imparatorlu�unu de�i�tirebilirsin.")
					say("")
					say_reward("�mparatorlu�unu de�i�tirmek istedi�in ki�inin ismini gir: ")
					imparatorDegistirmeIsim = input()
					oyuncuAra = find_pc_by_name(imparatorDegistirmeIsim)
					if oyuncuAra == 0 then
						say_title(uyariOL)
						say("")
						say_reward("Oyuncu bulunamad�.")
						say("")
						send_letter ("GM: Y�netim Paneli")
					else
						o_id = pc.select(oyuncuAra)
							oyuncuImparatorluk = pc.get_empire()
							if oyuncuImparatorluk == 1 then
								oyuncuImp = "Shinsoo"
							elseif oyuncuImparatorluk == 2 then
								oyuncuImp = "Chunjo"
							elseif oyuncuImparatorluk == 3 then
								oyuncuImp = "Jinno"
							end
						pc.select(o_id)
						say_title(uyariO)
						say("")
						say("Oyuncunun imparatorluk bilgileri: ")
						say("")
						say_reward("Oyuncunun �uan ki imparatorlu�u: "..oyuncuImp)
						say("")
						imparatorlukSecim = select("Shinsoo","Chunjo","Jinno","Kapat")
						if imparatorlukSecim == 1 then
							oyuncuAra_y = find_pc_by_name(imparatorDegistirmeIsim)
							if oyuncuAra_y != 0 then
								o_id_y = pc.select(oyuncuAra_y)
									pc.change_empire(1)
									syschat("Sistem: �mparatorlu�unuz y�netici taraf�ndan de�i�tirilmi�tir.")
									warp_to_village(pc.get_map_index())
								pc.select(o_id_y)
								say_title(uyariO)
								say("")
								say("Oyuncunun imparatorlu�u ba�ar� ile de�i�tirildi.")
								send_letter ("GM: Y�netim Paneli")
							else
								say_title(uyariOL)
								say("")
								say_reward("Oyuncu oyunda bulunamad�.")
								say("")
								send_letter ("GM: Y�netim Paneli")
							end
						elseif imparatorlukSecim == 2 then
							oyuncuAra_y = find_pc_by_name(imparatorDegistirmeIsim)
							if oyuncuAra_y != 0 then
								o_id_y = pc.select(oyuncuAra_y)
									pc.change_empire(2)
									syschat("Sistem: �mparatorlu�unuz y�netici taraf�ndan de�i�tirilmi�tir.")
									warp_to_village(pc.get_map_index())
								pc.select(o_id_y)
								say_title(uyariO)
								say("")
								say("Oyuncunun imparatorlu�u ba�ar� ile de�i�tirildi.")
								send_letter ("GM: Y�netim Paneli")
							else
								say_title(uyariOL)
								say("")
								say_reward("Oyuncu oyunda bulunamad�.")
								say("")
								send_letter ("GM: Y�netim Paneli")
							end
							
						elseif imparatorlukSecim == 3 then
							oyuncuAra_y = find_pc_by_name(imparatorDegistirmeIsim)
							if oyuncuAra_y != 0 then
								o_id_y = pc.select(oyuncuAra_y)
									pc.change_empire(3)
									syschat("Sistem: �mparatorlu�unuz y�netici taraf�ndan de�i�tirilmi�tir.")
									warp_to_village(pc.get_map_index())
								pc.select(o_id_y)
								say_title(uyariO)
								say("")
								say("Oyuncunun imparatorlu�u ba�ar� ile de�i�tirildi.")
								send_letter ("GM: Y�netim Paneli")
							else
								say_title(uyariOL)
								say("")
								say_reward("Oyuncu oyunda bulunamad�.")
								say("")
								send_letter ("GM: Y�netim Paneli")
							end
							
						elseif imparatorlukSecim == 4 then
							return
						end
					end
				elseif yoneticiPanelSecim == 8 then
					say_title(uyariO)
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("Buradan oyuncunun paras�n� g�ncelleyebilirsin.")
					say("")
					say_reward("Paras�n� g�ncellemek istedi�in oyuncunun ismini gir:")
					paraGuncelleOyuncuIs�m = input()
					paraGuncelleOyuncuAra = find_pc_by_name(paraGuncelleOyuncuIs�m)
					if paraGuncelleOyuncuAra == 0 then
						say_title(uyariOL)
						say("")
						say_reward("Oyuncu bulunamad�.")
						say("")
						send_letter ("GM: Y�netim Paneli")
					else
						say_title(uyariO)
						say("")
						o_para_id = pc.select(paraGuncelleOyuncuAra)
							oyuncuParasi = pc.get_money()
						pc.select(o_para_id)
						say_reward("Oyuncunun �uanki paras�: "..genel_veri(oyuncuParasi))
						say("")
						say_reward("Eklenecek ya da ��kar�lacak para mikar�n� girin:[ENTER]Para ��karmak i�in miktar�n ba��na - koyun. ")
						guncellenecekPara = tonumber(input())
						if guncellenecekPara == nil or guncellenecekPara == "" or guncellenecekPara == 0 then
							say_title(uyariOL)
							say("")
							say_reward("Ge�ersiz giri� yap�ld�. ��lemler s�f�rland�.")
							say("")
							send_letter ("GM: Y�netim Paneli")
						elseif guncellenecekPara > 2000000000 then 
							say_title(uyariOL)
							say("")
							say_reward("Girdi�iniz 2.000.000.000 miktar�ndan d���k olmal�.")
							say("")
							send_letter ("GM: Y�netim Paneli")
						else
							paraGuncelleOyuncuAra_y = find_pc_by_name(paraGuncelleOyuncuIs�m)
							if paraGuncelleOyuncuAra_y == 0 then
								say_title(uyariOL)
								say("")
								say_reward("Oyuncu bulunamad�.")
								send_letter ("GM: Y�netim Paneli")
							else
								oyuncuDizi = {}
								o_para_id_y = pc.select(paraGuncelleOyuncuAra_y)
									oyuncuSuankiPara = pc.get_money()
									if (guncellenecekPara+oyuncuSuankiPara) > 2000000000 then
										oyuncuDizi[1] = 0
									elseif (guncellenecekPara+oyuncuSuankiPara) < 0 then
										oyuncuDizi[1] = 1
									else
										if guncellenecekPara < 0 then
											oyuncuDizi[1] = 2
											pc.change_money(guncellenecekPara)
											syschat("Sistem: Hesab�n�zdan y�netici taraf�ndan "..genel_veri(guncellenecekPara).." para �ekilmi�tir.")
										else
											oyuncuDizi[1] = 2
											pc.change_money(guncellenecekPara)
											syschat("Sistem: Hesab�n�za y�netici taraf�ndan "..genel_veri(guncellenecekPara).." para aktar�lm��t�r.")
										end
									end
								pc.select(o_para_id_y)
								if oyuncuDizi[1] == 0 then
									say_title(uyariOL)
									say("")
									say_reward("Y�kledi�iniz para ile oyuncunun paras� s�n�r� a��yor.[ENTER]��lem iptal edildi.")
									say("")
									send_letter ("GM: Y�netim Paneli")
								elseif oyuncuDizi[1] == 1 then
									say_title(uyariOL)
									say("")
									say_reward("��kard���n�z para ile oyuncunun paras� eksiye d���yor.[ENTER]��lem iptal edildi.")
									say("")
									send_letter ("GM: Y�netim Paneli")
								elseif oyuncuDizi[1] == 2 then
									say_title(uyariO)
									say("")
									say("Para i�lemi ba�ar� ile ger�ekle�mi�tir.")
									say("")
									send_letter ("GM: Y�netim Paneli")
								end
							end
						end
					end
				elseif yoneticiPanelSecim == 9 then
					say_title(uyariO)
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("Buradan oyuncunun cinsiyetini de�i�tirebilirsiniz.")
					say("")
					say_reward("Cinsyetini de�i�tirmek istedi�in oyuncunun ismini gir: ")
					cinsiyetOyuncuIsim = input()
					cinsiyetOyuncuIsimAra = find_pc_by_name(cinsiyetOyuncuIsim)
					if cinsiyetOyuncuIsimAra == 0 then
						say_title(uyariOL)
						say("")
						say_reward("Oyuncu bulunamad�.")
						say("")
						send_letter ("GM: Y�netim Paneli")
					else
						cinsiyetOyuncuDizi = {}
						cinsiyet_oyuncu_id = pc.select(cinsiyetOyuncuIsimAra)
							if pc.is_married() then
								cinsiyetOyuncuDizi[1] = 0
							else
								pc.change_sex()
								syschat("Sistem: Cinsiyetiniz y�netici taraf�ndan de�i�tirilmi�tir.")
								warp_to_village(pc.get_map_index())
							end
						pc.select(cinsiyet_oyuncu_id)
						if cinsiyetOyuncuDizi[1] == 0 then
							say_title(uyariOL)
							say("")
							say_reward("Oyuncu evli oldu�u i�in cinsiyeti de�i�tirilemedi.")
							say("")
							send_letter ("GM: Y�netim Paneli")
						else
							say_title(uyariO)
							say("")
							say("Oyuncunun cinsiyeti ba�ar� ile de�i�tirilmi�tir.")
							say("")
							send_letter ("GM: Y�netim Paneli")
						end
					end
				elseif yoneticiPanelSecim == 10 then
					say_title(uyariO)
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("Buradan diledi�in oyuncuyu susturabilirsin.")
					say("")
					say_reward("Susturmak istedi�in oyuncunun ismini gir: ")
					susturmaOyuncuIsim = input()
					susturmaOyuncuIsimAra = find_pc_by_name(susturmaOyuncuIsim)
					if susturmaOyuncuIsimAra == 0 then
						say_title(uyariOL)
						say("")
						say_reward("Oyuncu bulunamad�.")
						say("")
						send_letter ("GM: Y�netim Paneli")
					else
						say_title(uyariO)
						say("")
						say_reward("Susturma nedeninizi giriniz: ")
						susturmaOyuncuNeden = input()
						if susturmaOyuncuNeden == "" then
							say_title(uyariOL)
							say("")
							say_reward("Susturma nedeni bo� olamaz. ��lem iptal edildi.")
							say("")
							send_letter ("GM: Y�netim Paneli")
						else
							say_title(uyariO)
							say("")
							say_reward("Susturmak istedi�iniz s�reyi giriniz:[ENTER](S�re dakika cinsindendir.)")
							oyuncuSusturmaSure = tonumber(input())
							if oyuncuSusturmaSure == nil or oyuncuSusturmaSure == "" or oyuncuSusturmaSure < 1 then
								say_title(uyariOL)
								say("")
								say_reward("Ge�ersiz giri� yap�ld�. ��lem iptal edildi.")
								say("")
								send_letter ("GM: Y�netim Paneli")
							else
								susturmaOyuncuIsimAra_y = find_pc_by_name(susturmaOyuncuIsim)
								if susturmaOyuncuIsimAra_y == 0 then
									say_title(uyariOL)
									say("")
									say_reward("Oyuncu bulunamad�.")
									say("")
									send_letter ("GM: Y�netim Paneli")
								else
									command("block_chat "..susturmaOyuncuIsim.." "..oyuncuSusturmaSure*(60))
									susturma_oyuncu_id = pc.select(susturmaOyuncuIsimAra_y)
										syschat("Sistem: Karakteriniz y�netici taraf�ndan "..oyuncuSusturmaSure.." dakika susturulmu�tur.")
										syschat("Sistem: Susturulma nedeni: "..susturmaOyuncuNeden)
									pc.select(susturma_oyuncu_id)
									say_title(uyariO)
									say("")
									say("Oyuncu ba�ar� ile susturulmu�tur.")
									say("")
									send_letter ("GM: Y�netim Paneli")
								end
							end
						end
					end
				elseif yoneticiPanelSecim == 11 then
					say_title(uyariO)
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("Buradan oyuncular�n derece puan�n� de�i�tirebilirsin.")
					say("")
					say_reward("Derecesini de�i�tirmek istedi�in oyuncunun ismini gir: ")
					dereceDegistirIsim = input()
					dereceDegistirIsimAra = find_pc_by_name(dereceDegistirIsim)
					if dereceDegistirIsimAra == 0 then
						say_title(uyariOL)
						say("")
						say_reward("Oyuncu bulunamad�.")
						say("")
						send_letter ("GM: Y�netim Paneli")
					else
						dereceDegistirDizi = {}
						derece_oyuncu_id = pc.select(dereceDegistirIsimAra)
							dereceDegistirDizi[1] = pc.get_alignment()
						pc.select(derece_oyuncu_id)
						say_title(uyariO)
						say("")
						say_reward("Oyuncunun derece puan�: "..dereceDegistirDizi[1])
						say("")
						say_reward("Eklenecek ya da ��kar�lacak derece mikar�n� girin:[ENTER](Derece azaltmak i�in miktar�n ba��na - koyun.)")
						guncellenecekDerece = tonumber(input())
						if guncellenecekDerece == nil or guncellenecekDerece == "" or guncellenecekDerece > 20000 or guncellenecekDerece < -20000 then
							say_title(uyariOL)
							say("")
							say_reward("Ge�ersiz giri� yap�ld�. ��lemler s�f�rland�.")
							say("")
							send_letter ("GM: Y�netim Paneli")
						else
							dereceDegistirIsimAra_y = find_pc_by_name(dereceDegistirIsim)
							if dereceDegistirIsimAra_y == 0 then
								say_title(uyariOL)
								say("")
								say_reward("Oyuncu bulunamad�.")
								send_letter ("GM: Y�netim Paneli")
							else
								o_derece_id_y = pc.select(dereceDegistirIsimAra_y)
									oyuncuSuankiDerece = pc.get_alignment()
									if (guncellenecekDerece+oyuncuSuankiDerece) > 20000 then
										dereceDegistirDizi[2] = 0
									elseif (guncellenecekDerece+oyuncuSuankiDerece) < -20000 then
										dereceDegistirDizi[2] = 1
									else
										if guncellenecekDerece < 0 then
											dereceDegistirDizi[2] = 2
											pc.change_alignment(guncellenecekDerece)
											syschat("Sistem: Hesab�n�zdan y�netici taraf�ndan "..genel_veri(guncellenecekDerece).." derece azalt�lm��t�r.")
										else
											dereceDegistirDizi[2] = 2
											pc.change_alignment(guncellenecekDerece)
											syschat("Sistem: Hesab�n�za y�netici taraf�ndan "..genel_veri(guncellenecekDerece).." derece aktar�lm��t�r.")
										end
									end
								pc.select(o_derece_id_y)
								if dereceDegistirDizi[2] == 0 then
									say_title(uyariOL)
									say("")
									say_reward("Y�kledi�iniz derece ile oyuncunun derece s�n�r� a��yor.[ENTER]��lem iptal edildi.")
									say("")
									send_letter ("GM: Y�netim Paneli")
								elseif dereceDegistirDizi[2] == 1 then
									say_title(uyariOL)
									say("")
									say_reward("Azalt���n�z derece ile oyuncunun derecesi s�n�r� a��yor.[ENTER]��lem iptal edildi.")
									say("")
									send_letter ("GM: Y�netim Paneli")
								elseif dereceDegistirDizi[2] == 2 then
									say_title(uyariO)
									say("")
									say("Derece i�lemi ba�ar� ile ger�ekle�mi�tir.")
									say("")
									send_letter ("GM: Y�netim Paneli")
								end
							end
						end
					end
				elseif yoneticiPanelSecim == 12 then
					say_title(uyariO)
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("Buradan diledi�in oyuncuya e�ya g�nderebilirsin.")
					say("")
					say_reward("E�ya g�ndermek istedi�in oyuncunun ismini gir: ")
					esyaGonderilecekIsim = input()
					esyaGonderilecekIsimAra = find_pc_by_name(esyaGonderilecekIsim)
					if esyaGonderilecekIsimAra == 0 then
						say_title(uyariOL)
						say("")
						say_reward("Oyuncu bulunamad�.")
						say("")
						send_letter ("GM: Y�netim Paneli")
					else
						say_title(uyariO)
						say("")
						say_reward("G�nderilecek e�yan�n kodunu gir: ")
						gonderilecekEsyaKodu = tonumber(input())
						if gonderilecekEsyaKodu == nil or gonderilecekEsyaKodu == "" then
							say_title(uyariOL)
							say("")
							say_reward("Ge�ersiz giri� yap�ld�. ��lemler s�f�rland�.")
							say("")
							send_letter ("GM: Y�netim Paneli")
						else
								say_title(uyariO)
								say("")
								say_reward("E�yadan ka� adet g�ndermek istiyorsun? ")
								gonderilecekEsyaAdeti = tonumber(input())
								if gonderilecekEsyaAdeti == nil or gonderilecekEsyaAdeti == "" or gonderilecekEsyaAdeti < 1 or gonderilecekEsyaAdeti > 1000 then
									say_title(uyariOL)
									say("")
									say_reward("Ge�ersiz giri� yap�ld�. ��lemler s�f�rland�.")
									say("")
									send_letter ("GM: Y�netim Paneli")
								else
									esyaGonderilecekIsimAra_y = find_pc_by_name(esyaGonderilecekIsim)
									if esyaGonderilecekIsim == 0 then
										say_title(uyariOL)
										say("")
										say_reward("Oyuncu bulunamad�.")
										say("")
										send_letter ("GM: Y�netim Paneli")
									else
										say_title(uyariO)
										say("")
										say_reward("E�yay� nas�l g�ndermek istiyorsun? ")
										basicTypeSelect = select("Kilitli","Kilitsiz")
										if basicTypeSelect == 1 then
											oyuncu_esyaGonderme_id = pc.select(esyaGonderilecekIsimAra_y)
											pc.give_item3(gonderilecekEsyaKodu,gonderilecekEsyaAdeti)
											syschat("Sistem: Y�netici taraf�ndan �antan�za kilitli e�ya g�nderilmi�tir.")
											pc.select(oyuncu_esyaGonderme_id)
											say_title(uyariO)
											say("")
											say("Kilitli E�ya ba�ar� ile g�nderildi.")
											say("")
										else
											oyuncu_esyaGonderme_id = pc.select(esyaGonderilecekIsimAra_y)
											pc.give_item2(gonderilecekEsyaKodu,gonderilecekEsyaAdeti)
											syschat("Sistem: Y�netici taraf�ndan �antan�za e�ya g�nderilmi�tir.")
											pc.select(oyuncu_esyaGonderme_id)
											say_title(uyariO)
											say("")
											say("Kilitsiz E�ya ba�ar� ile g�nderildi.")
											say("")
										end
										send_letter ("GM: Y�netim Paneli")
								end
							end
						end
					end
				elseif yoneticiPanelSecim == 13 then
					say_title(uyariO)
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("Buradan oyuncunun stat�s�n� s�f�rlayabilirsin.")
					say("")
					say_reward("Stat�s�n� s�f�rlamak istedi�in oyuncunun ismini gir: ")
					statuSifirlaIsim = input()
					statuSifirlaIsimAra = find_pc_by_name(statuSifirlaIsim)
					if statuSifirlaIsimAra == 0 then
						say_title(uyariOL)
						say("")
						say_reward("Oyuncu bulunamad�.")
						say("")
						send_letter ("GM: Y�netim Paneli")
					else
						statu_id = pc.select(statuSifirlaIsimAra)
							char_log(0,"RESET_ALL","RESET_STAT_POINTS") 
							pc.reset_point() 
							char_log( 0,"RESET_ALL","RESET_END")
							syschat("Sistem: Stat�n�z oyun y�neticisi taraf�ndan s�f�rlanm��t�r.")
						pc.select(statu_id)
						say_title(uyariO)
						say("")
						say("Oyuncunun stat�s� ba�ar� ile s�f�rlanm��t�r.")
						say("")
						send_letter ("GM: Y�netim Paneli")
					end
				elseif yoneticiPanelSecim == 14 then
					syschat_light_green("Harita Kodu: "..pc.get_map_index().."")
					syschat_light_green("Warp X Kordinat�: "..pc.get_x().." / Warp Y Kordinat�: "..pc.get_y().."")
					syschat_light_green("Go X Kordinat�: "..pc.get_local_x().." / Go Y Kordinat�: "..pc.get_local_y().."")
					send_letter ("GM: Y�netim Paneli")
				elseif yoneticiPanelSecim == 15 then
					send_letter ("GM: Y�netim Paneli")
					setskin(1)
					say_size(350,350)
					say_title("Flag Kontrol")
					say("")
					say("Merhaba y�netici, "..yoneticiIsim)
					say("Buradan oyundaki y�netici flaglar�n� ��renebilirsin.")
					say_orange("A�a��da bahsi ge�en flaglar� bilmiyorsan�z kullanmay�n!")
					say("")
					say("Zaman Flaglar� sonuna saniye cinsinden s�re belirtmelisiniz.")
					say_blue2("Ba��rma S�resi (Default 15 saniye): /e bagirma_zaman 15")
					say_green("�uan "..gelismis_yonetici_sistemi.SureKontrol("bagirma_zaman").." saniye olarak ayarl�d�r!")
					wait()
					say("Ticaret Cam� Engeli (1 Kapat�r/0 A�ar): �uan "..gelismis_yonetici_sistemi.FlagKontrol("disable_shop_search",0))
					say_blue2("Kullan�m: /e disable_shop_search 0")
					say_yellow("-------------------------")
					say_green("Ticaret Cam� Extra (1 Kapat�r/0 A�ar): �uan "..gelismis_yonetici_sistemi.FlagKontrol("warp_search_enable",0))
					say_blue2("Kullan�m: /e warp_search_enable 0")
					say_yellow("-------------------------")
					say_green("Ba��rma Engeli (0 Kapat�r/1 A�ar): �uan "..gelismis_yonetici_sistemi.FlagKontrol("bagirma_kapat",0))
					say_blue2("Kullan�m: /e bagirma_kapat 0")
					say_yellow("-------------------------")
					say_green("Pazar Engeli (0 Kapat�r/1 A�ar): �uan "..gelismis_yonetici_sistemi.FlagKontrol("shop_off",0))
					say_blue2("Kullan�m: /e shop_off 0")
					wait()
					say_green("Youtuber Ekran� Engeli (0 Kapat�r/1 A�ar): �uan "..gelismis_yonetici_sistemi.FlagKontrol("disable_youtube_system",0))
					say_blue2("Kullan�m: /e disable_youtube_system 0")
					say_yellow("-------------------------")
					say_green("Pet Sistemi Engeli (0 Kapat�r/1 A�ar): �uan "..gelismis_yonetici_sistemi.FlagKontrol("pet_kapat",0))
					say_blue2("Kullan�m: /e pet_kapat 0")
					say_yellow("-------------------------")
					say_green("Exp Chat (0 Kapat�r/1 A�ar): �uan "..gelismis_yonetici_sistemi.FlagKontrol("exp_bonus_log",0))
					say_blue2("Kullan�m: /e exp_bonus_log 0")
					say_yellow("-------------------------")
					say_green("Sorun Bildir (0 Kapat�r/1 A�ar): �uan "..gelismis_yonetici_sistemi.FlagKontrol("report_system",0))
					say_blue2("Kullan�m: /e report_system 0")
					say_yellow("-------------------------")
					say_green("NPC Sat�n Alma Kontrol� (0 Kapat�r/1 A�ar): �uan "..gelismis_yonetici_sistemi.FlagKontrol("npc_sure_limit",0))
					say_blue2("Kullan�m: /e npc_sure_limit 0")
					--local kapat = select("Pencereyi Kapat")
				elseif yoneticiPanelSecim == 16 then
					setskin(NOWINDOW)
					cmdchat(string.format("ShowCaptcha %d", 30))
				elseif yoneticiPanelSecim == 17 then
					return
				end -- bana laz�m olan end
			elseif yoneticiSecim == 2 then
				return
			end
		end	
		
		function EventListesi(type)
			event_list = {
				[0] = {"Binek Par�omeni ", "Sevgililer G�n� ", "Bulmaca Kutusu ", "Oyma Ta� ", "Futbol Topu ", "Okey Kart ", "Ay����� Define Sand��� ", "Alt�gen Hediye Paketi ", "Kelime ", "Derece Puan� ", "D�nya Kupas� ", "Olimpiyat ", "Cad�lar Bayram� ", "Evcil Hayvan ", "Y�lba�� ", "Ramazan Simiti ", "D�nya Kitap G�n� ", "Y�ld�n�m� Paras� ", "Baashido Avc�lar� ", "S�per Metin ", "Bal�k Yapboz ", "Metin Katlama ", "Soru Cevap ", "Evrim Puani ", "Y�kseltme ", "Yaz ", "Ronark ", "Paskalya ", "Oyuncu G�n� ", "Sans Kutusu ", "G��l� Meley ", "Simya Takas ", "Trivia ", "Yutnori ", "Kral� Yakala ", "Patron Avc�lar� "},
				[1] = {"2017_mount_drop", "2017_valentine_drop", "2017_kids_drop", "2017_carving_stone_drop", "2017_football_drop", "cards_event", "2017_moon_drop", "2017_hexagon_drop", "word_event_drop", "alignment_event", "dunyakupasi_event", "2017_olympic_drop", "2017_halloween_drop", "2017_pet_drop", "2017_xmas_drop", "2017_ramadan_drop", "worldbookday", "2017_year_round_event", "2018_boss_hunters_event", "super_metin_event", "2018_fish_event", "scp_metinkatla", "scp_soru_event", "rarity_event", "yukseltme_event", "scp_yaz_etk", "blood_dungeon_login", "paskalya", "oyuncu_gunu", "sans_kutusu", "guclu_meley", "simyatakas", "trivia", "enable_yutnori", "enable_catch_king_event", "enable_attendance_event", "auto_event_source"},}
			return event_list[type]
		end
		
		function EventYonetim(type_, event_name, event_flag)
			if type_ == 1 then
				notice_all(event_name.." Etkinli�i ba�lad�!")
				notice_all("Gerekli bilgileri sa� �stteki event penceresinden alabilirsiniz.")
				game.set_event_flag(event_flag,1)
			else
				notice_all(event_name.." Etkinli�i sona erdi!")
				notice_all("Y�netim ekibi iyi oyunlar diler.")
				game.set_event_flag(event_flag,0)
			end
		end
		
		function FlagKontrol(flag_name,flag_type)
			if flag_type == 0 then
				if game.get_event_flag(flag_name) == 0 then
					return color256(255, 0, 0).."Kapal� "
				else
					return color256(0, 255, 0).."A��k "
				end
			else
				if game.get_event_flag(flag_name) == 1 then
					return color256(255, 0, 0).."Kapal� "
				else
					return color256(0, 255, 0).."A��k "
				end
			end
		end
		
		function SureKontrol(flag_name)
			if game.get_event_flag(flag_name) == 0 then
				return color256(0, 255, 0).."15"
			else
				return color256(0, 255, 0)..game.get_event_flag(flag_name)
			end
		end
		
		function isOpen()
			if scpEventOptions["isOpen"] == 0 then
				return "Kapal� "
			else
				return "A��k"
			end
		end
		function canOpenAble()
			local name = item_name(scpEventOptions["itemVnum"])
			local oran = scpEventOptions["dropPer"]
			-- local level = scpEventOptions["maxLevel"]
			return ( name!="" and oran<100 and oran>0 )
		end
		function set_cost(tp, cs)
			game.set_event_flag("scp_altin_"..tp, cs)
		end
		
		function dropKontrol(gelen_drop_bilgisi)
			dropBilgisi = gelen_drop_bilgisi
			if dropBilgisi == nil or dropBilgisi == "" or dropBilgisi < 1 then
				return false
			else
				return true
			end
		end
	end
end