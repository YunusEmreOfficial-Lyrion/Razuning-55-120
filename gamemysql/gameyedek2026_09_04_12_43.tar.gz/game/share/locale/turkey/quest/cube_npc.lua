quest maviruh_cube_list begin
    state start begin
        when
            20091.take or
            20066.take
        begin
            command("cube open")
        end
    end
end

quest maviruh_cube begin
    state start begin
        when 20091.chat."Paneli aç " with pc.level >= 15 begin
            npckodu = mob_name(20091)
            say_title(" "..npckodu.." ")
            say("")
            say("Panel açıldı. ")
            wait()
            setskin(NOWINDOW)
            command("cube open")
        end
        when 20066.chat."Paneli aç " with pc.level >= 50 begin
            npckodu = mob_name(20066)
            say_title(" "..npckodu.." ")
            say("")
            say("Panel açıldı. ")
            wait()
            setskin(NOWINDOW)
            command("cube open")
        end
    end
end