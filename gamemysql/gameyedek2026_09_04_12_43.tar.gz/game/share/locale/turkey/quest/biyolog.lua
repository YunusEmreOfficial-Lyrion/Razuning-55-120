quest isobiyolog begin
	state start begin
		when login begin
		setstate(basla)
		end
	end
	state basla begin
		when 20091.chat."Biyolog G�revleri ( TEK TIK )" begin
			say_title("Epic Sura")
			say ("") 
			say ("Merhaba, "..pc.getname().." ") 
	say (" ") 
			say ("Sald�r� De�eri +50 (Kal�c�) ") 
			say ("+10% Di�er Oyunculara Kar�� G�� (Kal�c�)")  
			say ("Hareket H�z� +10% , +500 HP (Kal�c�)")
			say ("Sald�r� H�z� +15% (Kal�c�) ")  
			say ("+10% Di�er Oyunculara Kar�� Savunma (Kal�c�) ") 
			say ("Savunma +50 (Kal�c�) ")  
			say ("�zelliklerini kazand�n�z!") 
			say ("") 
			say ("") 
			wait ( )
			say_title("Usta")
            affect.add_collect(apply.ATT_BONUS_TO_WARRIOR,10,60*60*24*365*60)
            affect.add_collect(apply.ATT_BONUS_TO_ASSASSIN,10,60*60*24*365*60)
            affect.add_collect(apply.ATT_BONUS_TO_SURA,10,60*60*24*365*60)
            affect.add_collect(apply.ATT_BONUS_TO_SHAMAN,10,60*60*24*365*60)
			affect.add_collect(apply.ATT_SPEED,15,60*60*24*365*60)
			affect.add_collect(apply.MAX_HP,500,60*60*24*365*60)
			affect.add_collect(apply.MOV_SPEED,10,60*60*24*365*60)
			affect.add_collect(apply.DEF_GRADE_BONUS,60,60*60*24*365*60)
			affect.add_collect(apply.ATT_GRADE_BONUS,50,60*60*24*365*60)
            affect.add_collect(apply.RESIST_WARRIOR,10,60*60*24*365*60)
            affect.add_collect(apply.RESIST_ASSASSIN,10,60*60*24*365*60)
            affect.add_collect(apply.RESIST_SURA,10,60*60*24*365*60)
            affect.add_collect(apply.RESIST_SHAMAN,10,60*60*24*365*60)
			say ("") 
			say ("T�m �zellikleri ba�ar� ile ald�n!")
			say ("Di�er �zellikle i�in Epic Sura ")
			say ("ile g�r��ebilirsin.") 
			say ("�yi oyunlar dileriz.") 
			setstate(epic)
		end
	end	
	state epic begin
		when 20091.chat."92. Level Epic G�revi" begin
			say_title ("Epic Sura")
			say (" ") 
			say ("Merhaba, "..pc.getname().." ") 
	say (" ") 
			say ("Epic g�revlerini yapt���n i�in. " )
			say ("birini se�tikten sonra di�er g�rev i�in tekrar u�ra. " )
			say (" ") 
			say ("Bu �d�llerden birini se�men gerek; " )
			say (" ") 
			local s = select ( " +1100 HP " , " Savunma De�eri +120 " , " Sald�r� De�eri +60 ") 
			if s == 1 then 
			affect.add_collect(apply.MAX_HP,1100,60*60*24*365*60)
			setstate(gec2)
			elseif s == 2 then 
			affect.add_collect(apply.DEF_GRADE_BONUS,120,60*60*24*365*60)
			setstate(gec2)
			elseif s == 3 then 
			affect.add_collect(apply.ATT_GRADE_BONUS,60,60*60*24*365*60)
			setstate(gec2)
			end
		end
	end
	state gec2 begin
		when 20091.chat."94. Level Epic G�revi" begin
			say_title ("Epic Sura")
			say (" ") 
			say ("Merhaba, "..pc.getname().." ") 
	say (" ") 
			say ("Epic g�revlerini yapt���n i�in, " )
			say (" ") 
			say ("Bu �d�llerden birini se�men gerek; " )
			say (" ") 
			local s = select ( " +4000 HP " , " Savunma De�eri +140 " , " Sald�r� De�eri +70 " ) 
			if s == 1 then 
			affect.add_collect(apply.MAX_HP,4000,60*60*24*365*60) 
			setstate(isosifirla)
			elseif s == 2 then 
			affect.add_collect(apply.DEF_GRADE_BONUS,140,60*60*24*365*60)
			setstate(isosifirla)
			elseif s == 3 then 
			affect.add_collect(apply.ATT_GRADE_BONUS,70,60*60*24*365*60)
			setstate(isosifirla) 
			end 
		end
	end
	state isosifirla begin
	when 20091.chat."92-94 G�revimi de�i�tir" begin
    if get_time()<=pc.getqf("zaman5") then
	say_title ("Epic Sura")
	say (" ") 
	say ("Merhaba, "..pc.getname().." ") 
	say (" ") 
    say ("Yine mi 92-94 g�revini de�i�tirmek istiyorsun?")
	say ("�zg�n�m t�m hakk�n� kullanm��s�n...")
	say (" ") 
	say (" ") 
    else
	say_title ("Epic Sura")
	say (" ") 
	say ("Merhaba, "..pc.getname().." ") 
	say (" ") 
	say ("Senin i�in bir kereye mahsus 92-94 �zelliklerini")
	say ("de�i�tirebilirim.")
	say (" ") 
	say (" ") 
    local al = select ("Getirece�im.")
    if al == 1  then
	say_title ("Epic Sura")
	say (" ") 
    say("92. Level Epic G�revi")
    pc.setqf("zaman5", get_time()+87666*60)
			affect.remove_collect(apply.MAX_HP,1100,60*60*24*365*60)
			affect.remove_collect(apply.DEF_GRADE_BONUS,120,60*60*24*365*60)
			affect.remove_collect(apply.ATT_GRADE_BONUS,60,60*60*24*365*60)
			affect.remove_collect(apply.MAX_HP,4000,60*60*24*365*60)
			affect.remove_collect(apply.DEF_GRADE_BONUS,140,60*60*24*365*60)
			affect.remove_collect(apply.ATT_GRADE_BONUS,70,60*60*24*365*60)
	say (" ") 
			say("Unutma bir daha etkilerini de�i�tiremezsin!")
	say (" ") 
            local s = select ( " +1100 HP " , " Savunma De�eri +120 " , " Sald�r� De�eri +60 " ) 
			if s == 1 then 
			affect.add_collect(apply.MAX_HP,1100,60*60*24*365*60)
			elseif s == 2 then 
			affect.add_collect(apply.DEF_GRADE_BONUS,120,60*60*24*365*60)
			elseif s == 3 then 
			affect.add_collect(apply.ATT_GRADE_BONUS,60,60*60*24*365*60)
			end
	say_title ("Epic Sura")
	say (" ") 
    say("94. Level Epic G�revi")
	say (" ") 
			say("Se�imini ak�ll�ca yap!")
	say (" ") 
			local s = select ( " +4000 HP " , " Savunma De�eri +140 " , " Sald�r� De�eri +70 " ) 
			if s == 1 then 
			affect.add_collect(apply.MAX_HP,4000,60*60*24*365*60)
			elseif s == 2 then 
			affect.add_collect(apply.DEF_GRADE_BONUS,140,60*60*24*365*60)
			elseif s == 3 then 
			affect.add_collect(apply.ATT_GRADE_BONUS,70,60*60*24*365*60)
			end
		end
		end
		end
		end
		end
