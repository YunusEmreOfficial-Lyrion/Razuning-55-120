#!/bin/sh
#
#
#
#
# BU KISMI DUZENLE.#
ISIM=yedekler #Yedek klasörünün ismini buraya yaz...
YOL2=/usr/Razuning-V5 #Kaynak kodlarının lokasyonunu buraya yaz...
YOL3=/var/db #MYSQL yedeği için değiştirmene gerek yok...
YOL4=/usr #Filesin lokasyonunu yaz...
YOL5=/root #Yedek klasörü nerede olsun lokasyonunu buraya yaz...
#
#
#
#
#
#
#
#
#
#
#
clear
echo -e "\e[21mMetin2House Gelistirici Scripti\e[0m"
echo -e "\e[96m-----------------------------------.\e[0m"
echo -e "\e[92m1 - KAYNAK YEDEGI AL\e[0m"
echo -e "\e[92m2 - KAYNAK YEDEKLERINI LISTELE\e[0m"
echo -e "\e[92m3 - KAYNAK YEDEGINI GERI YUKLE\e[0m"
echo -e "\e[93m4 - GAME YEDEGI AL\e[0m"
echo -e "\e[93m5 - GAME YEDEKLERINI LISTELE\e[0m"
echo -e "\e[93m6 - GAME YEDEGINI GERI YUKLE\e[0m"
echo -e "\e[94m7 - MYSQL YEDEGI AL\e[0m"
echo -e "\e[94m8 - MYSQL YEDEKLERINI LISTELE\e[0m"
echo -e "\e[94m9 - MYSQL YEDEGINI GERI YUKLE\e[0m"
read secim
case $secim in
1*)
cd $YOL5
if [ -d $YOL5/$ISIM/kaynak/]; then
sleep 1
else
echo -e "\e[92mYEDEK KLASORU OLUSTURULDU...\e[0m"
mkdir $ISIM
cd $YOL5/$ISIM/
mkdir kaynak
fi
cd $YOL2/ && tar czvf gecici.tar.gz Server
clear
echo -e "\e[92mGECICI SOURCE YEDEGI OLUSTURULDU...\e[0m"
sleep 2
clear
cp gecici.tar.gz "$YOL5/$ISIM/kaynak/sourceyedek$(date '+%Y_%m_%d_%H_%M').tar.gz"
sleep 2
cd $YOL2 && rm -rf gecici.tar.gz
echo -e "\e[92mSOURCE YEDEKLEME TAMAMLANDI...\e[0m"
echo -e "\e[92mYEDEKLERI $YOL5/$ISIM/kaynak  KLASORUNDE BULABILIRSIN...\e[0m"
sleep 1
;;
2*)
clear
echo -e "\e[92mSOURCE YEDEKLERI...\e[0m"
cd $YOL5/$ISIM/kaynak/
ls
;;
3*)
echo -e "\e[92mGERI YUKLEMEK ISTEDIGIN ARSIVIN TAM ADINI YAZ...\e[0m"
read yedek
cd $YOL5/$ISIM/kaynak/
cp $yedek $YOL2/
sleep 2
cd $YOL2/
rm -rf Server
sleep 2
tar zxvf $yedek
sleep 2
rm -rf $yedek
clear
echo -e "\e[92mYEDEK GERI YUKLENDI...\e[0m"
;;
4*)
cd $YOL5
if [ -d $YOL5/$ISIM/kaynak/]; then
sleep 1
else
echo -e "\e[92mYEDEK KLASORU OLUSTURULDU...\e[0m"
mkdir $ISIM
cd $YOL5/$ISIM/
mkdir game
fi
cd $YOL4/ && tar czvf gecici.tar.gz game
clear
echo -e "\e[92mGECICI GAME YEDEGI OLUSTURULDU...\e[0m"
sleep 2
clear
cp gecici.tar.gz "$YOL5/$ISIM/game/gameyedek$(date '+%Y_%m_%d_%H_%M').tar.gz"
sleep 2
cd $YOL4 && rm -rf gecici.tar.gz
echo -e "\e[92mGAME YEDEKLEME TAMAMLANDI...\e[0m"
echo -e "\e[92mYEDEKLERI $YOL5/$ISIM/game  KLASORUNDE BULABILIRSIN...\e[0m"
sleep 1
;;
5*)
clear
echo -e "\e[92mGAME YEDEKLERI...\e[0m"
cd $YOL5/$ISIM/game/
ls -R
;;
6*)
echo -e "\e[92mGERI YUKLEMEK ISTEDIGIN ARSIVIN TAM ADINI YAZ...\e[0m"
read yedek
cd $YOL5/$ISIM/game/
cp $yedek $YOL4/
sleep 2
cd $YOL4/
rm -rf game
sleep 2
tar zxvf $yedek
sleep 2
rm -rf $yedek
clear
echo -e "\e[92mYEDEK GERI YUKLENDI...\e[0m"
;;
7*)
cd $YOL5
if [ -d $YOL5/$ISIM/mysql/]; then
sleep 1
else
echo -e "\e[92mYEDEK KLASORU OLUSTURULDU...\e[0m"
mkdir $ISIM
cd $YOL5/$ISIM/
mkdir mysql
fi
cd $YOL3/ && tar czvf gecici.tar.gz mysql
clear
echo -e "\e[92mGECICI MYSQL YEDEGI OLUSTURULDU...\e[0m"
sleep 2
clear
cp gecici.tar.gz "$YOL5/$ISIM/mysql/mysqlyedek$(date '+%Y_%m_%d_%H_%M').tar.gz"
sleep 2
cd $YOL3 && rm -rf gecici.tar.gz
echo -e "\e[92mMYSQL YEDEKLEME TAMAMLANDI...\e[0m"
echo -e "\e[92mYEDEKLERI $YOL5/$ISIM/mysql  KLASORUNDE BULABILIRSIN...\e[0m"
sleep 1
;;
8*)
clear
echo -e "\e[92mMYSQL YEDEKLERI...\e[0m"
cd $YOL5/$ISIM/mysql/
ls -R
;;
9*)
echo -e "\e[92mGERI YUKLEMEK ISTEDIGIN ARSIVIN TAM ADINI YAZ...\e[0m"
read yedek
cd $YOL5/$ISIM/mysql/
cp $yedek $YOL3/
sleep 2
cd $YOL3/
rm -rf mysql
sleep 2
tar zxvf $yedek
sleep 2
rm -rf $yedek
clear
echo -e "\e[92mYEDEK GERI YUKLENDI...\e[0m"
;;
esac